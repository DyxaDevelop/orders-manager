import React from 'react';
import './Style.css';

class UserInvoices extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div></div>
        )
    }
}

export default UserInvoices;